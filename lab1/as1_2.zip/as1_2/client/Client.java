package client;

public class Client {

    int portNumber;
    String hostName;

    public Client(int portNumber, String hostName){
        this.portNumber = portNumber;
        this.hostName = hostName;
    }

    public void run() throws InterruptedException {

        ClientTcpChannel tcpChannel = new ClientTcpChannel(portNumber, hostName);
        ClientUdpChannel udpChannel = new ClientUdpChannel(portNumber, hostName);

        tcpChannel.createSocket();
        udpChannel.createSocket();
        
        InputConsole inputConsole = new InputConsole(tcpChannel, udpChannel);
        Thread console = new Thread(inputConsole);

        console.start();

        tcpChannel.run();        
        udpChannel.run();

        console.join();
        


    }


}
