package client;

import java.io.IOException;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;



public class ClientUdpChannel implements ClientChannel{
    
    int portNumber;
    String hostName;

    DatagramSocket socket = null;

    public ClientUdpChannel( int portNumber, String hostName ) {
        this.portNumber = portNumber;
        this.hostName = hostName;
    }

    @Override
    public void run() throws InterruptedException {
        
        MessageHandler messageHandler = new MessageHandler();

        Thread messageThread = new Thread(messageHandler);

        messageThread.start();
        
    }

    @Override
    public void createSocket(){
        try {
            socket = new DatagramSocket();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void sendMessageToServer() {

        try {
            InetAddress address = InetAddress.getByName("localhost");
            byte[] sendBuffer = "Ping Java Udp!".getBytes();

            DatagramPacket sendPacket = new DatagramPacket(sendBuffer, sendBuffer.length, address, portNumber);
            socket.send(sendPacket);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private class MessageHandler implements Runnable {

        @Override
        public void run() {
            try {
                byte[] receiveBuffer = new byte[1024];

                DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);
            
                socket.receive(receivePacket);

                String msg = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println(msg);

            } catch (IOException e) {
                e.printStackTrace();
            }
            
        }

    
        
    }

}
